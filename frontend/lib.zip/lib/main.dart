import 'package:flutter/material.dart';
import 'package:pos_system/providers/cart_provider.dart';
import 'package:pos_system/providers/orders_provider.dart';
import 'package:provider/provider.dart';
import '/pages/pos_dashboard.dart';
import 'package:http/http.dart' as http;
import 'providers/product_provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(
          create: (_) => ProductsProvider()..fetchProducts(),
        ),
        ChangeNotifierProvider(create: (_) => OrdersProvider()),
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PosDashboardPage(),
    );
  }
}
