import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../pages/orders_page.dart';
import '../services/product_service.dart';
import '../models/product_model.dart';
import '../reusable widgets/HoverArchiveWidget.dart';
import '../services/orders_service.dart';
import '../providers/cart_provider.dart';
import '../providers/product_provider.dart';
import 'package:image_picker/image_picker.dart';
import '../reusable widgets/FiltersSheet.dart';
import '../reusable widgets/PostProductDialogWidget.dart';

class PosDashboardPage extends StatefulWidget {
  const PosDashboardPage({super.key});

  @override
  State<PosDashboardPage> createState() => _PosDashboardPageState();
}

class _PosDashboardPageState extends State<PosDashboardPage> {
  // ================= DATA =================
  final postProductService _productService = postProductService();
  final ArchiveProductService _archiveProductService = ArchiveProductService();
  // these are for testing purposes
  final productService _service = productService();
  // String? searchQuery;
  //late String? searchQuery = _service.searchQuery;
  //_service.searchQuery = searchQuery;
  final searchQueryController = TextEditingController();

  // Text controllers for posting products
  final postProductNameController = TextEditingController();
  final postProductPriceController = TextEditingController();
  final postProductStorageQuantityController = TextEditingController();
  Timer? _debounceTimer; // for debouncing so i get a better ux

  // Image picking
  File? _pickedImageFile;
  final ImagePicker _picker = ImagePicker();

  // ================= INIT =================
  @override
  void initState() {
    super.initState();
    // Load initial products when the page opens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProductsProvider>().fetchProducts();
    });
  }

  @override
  void dispose() {
    //for the search field
    _debounceTimer?.cancel();
    searchQueryController.dispose();

    postProductNameController.dispose();
    postProductPriceController.dispose();
    postProductStorageQuantityController.dispose();
    super.dispose();
  }

  //=========Search Handler method============

  // Real-time search with debounce it wassssss hard to look for
  void _onSearchChanged(String value) {
    // Cancel previous timer
    _debounceTimer?.cancel();

    // Start new timer (wait 500ms after the mr.USER to stop typing i think 500 ms is not enough imma make it longer like 750 or 1000)
    _debounceTimer = Timer(const Duration(milliseconds: 750), () {
      if (mounted) {
        _performSearch();
      }
    });
  }

  Future<void> _performSearch() async {
    // Get the search text from the controller
    final query = searchQueryController.text.trim();

    // Get the provider and refresh with search
    final provider = context.read<ProductsProvider>();

    try {
      // Reset to first page when searching just a small method i made in the provider that only has _currentPage = 1 and thats it :)
      provider.resetPagination();

      // Fetch products with the new search query the server side one still tesingggg
      await provider.fetchProducts(
        searchQuery: query.isNotEmpty ? query : null,
      );

      // Clear focus to dismiss keyboard makes for a better ux
      FocusScope.of(context).unfocus();
    } catch (e) {
      debugPrint('Search error: $e');
      // Show error to user maybe later but for now imma keep it internal only
    }
  }

  // ================= FILTER SHEET =================
  //was here now its in a seperate file in reusable widgets
  // ================= CART LOGIC =================
  void _removeFromCart(int productId) {
    context.read<CartProvider>().removeFromCart(productId);
  }

  // ================= CHECKOUT =================
  void _handleCheckout() async {
    List<Map<String, dynamic>> itemsForApi = context
        .read<CartProvider>()
        .cart
        .values
        .map(
          (item) => {"product_id": item.product.id, "quantity": item.quantity},
        )
        .toList();
    debugPrint("items for api:$itemsForApi");

    try {
      final result = await OrderService().createOrder(itemsForApi);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Order #${result.id} placed! Total: \$${result.total}"),
        ),
      );

      await context.read<ProductsProvider>().refresh();
      context.read<CartProvider>().clearCart();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e"), backgroundColor: Colors.red),
      );
    }
  }

  // ================= POST PRODUCT DIALOG =================

  // ================= ARCHIVE PRODUCT =================
  void _archiveProduct(int productId) async {
    try {
      await context.read<ProductsProvider>().archiveProduct(productId);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Product archived successfully'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to archive: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // ================= UI WIDGETS =================
  Widget _buildHeaderIconButton({
    required IconData icon,
    required String tooltip,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(8),
      ),
      child: IconButton(
        icon: Icon(icon, color: const Color(0xFF0277FA), size: 20),
        onPressed: onPressed,
        tooltip: tooltip,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenWidth = constraints.maxWidth;
        final screenHeight = constraints.maxHeight;
        final productsProv = context.watch<ProductsProvider>();
        // Responsive calculations
        final cartPanelWidth = screenWidth > 1200
            ? 420
            : screenWidth > 800
            ? 380
            : 340;

        final gridCrossAxisCount = screenWidth > 1400
            ? 5
            : screenWidth > 1100
            ? 4
            : screenWidth > 800
            ? 3
            : 2;

        final gridChildAspectRatio = screenWidth > 1400
            ? 0.85
            : screenWidth > 1100
            ? 0.9
            : 1.0;

        return Scaffold(
          body: Container(
            decoration: const BoxDecoration(color: Colors.white),
            child: Row(
              children: [
                // ================= LEFT PRODUCTS PANEL =================
                Expanded(
                  child: Column(
                    children: [
                      // Search Header
                      Container(
                        height: 80,
                        padding: EdgeInsets.symmetric(
                          horizontal: screenWidth > 800 ? 24 : 16,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border(
                            bottom: BorderSide(color: Colors.grey.shade300),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            // Search field
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade100,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 16,
                                      ),
                                      child: Icon(
                                        Icons.search,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    Expanded(
                                      child: TextField(
                                        controller: searchQueryController,
                                        decoration: InputDecoration(
                                          hintText:
                                              'Search all products here...',
                                          border: InputBorder.none,
                                          hintStyle: TextStyle(
                                            color: Colors.grey.shade600,
                                          ),
                                          // Optional: Add clear button
                                          suffixIcon:
                                              searchQueryController
                                                  .text
                                                  .isNotEmpty
                                              ? IconButton(
                                                  icon: const Icon(
                                                    Icons.clear,
                                                    size: 20,
                                                  ),
                                                  onPressed: () {
                                                    searchQueryController
                                                        .clear();
                                                    _performSearch(); // Search with empty query to clear search //MARK: IM HERE SEACH
                                                  },
                                                )
                                              : null,
                                        ),
                                        onSubmitted: (value) =>
                                            _performSearch(),

                                        // for real time search
                                        onChanged: _onSearchChanged,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            SizedBox(width: screenWidth > 800 ? 20 : 12),

                            // Filter button
                            _buildHeaderIconButton(
                              icon: Icons.filter_list,
                              tooltip: 'Filter',
                              onPressed: () {
                                openFilterSheet(context);
                              },
                            ),

                            SizedBox(width: screenWidth > 800 ? 12 : 8),

                            // Orders button
                            _buildHeaderIconButton(
                              icon: Icons.receipt_long,
                              tooltip: 'View Orders',
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const OrdersPage(),
                                  ),
                                );
                              },
                            ),

                            SizedBox(width: screenWidth > 800 ? 20 : 12),

                            // Add Product button
                            SizedBox(
                              height: 40,
                              child: ElevatedButton.icon(
                                // Inside your button's onPressed in pos_dashboard.dart
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) =>
                                        const Postproductdialogwidget(),
                                  );
                                },

                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF0277FA),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 0,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                icon: const Icon(
                                  Icons.add,
                                  color: Colors.white,
                                  size: 16,
                                ),
                                label: Text(
                                  'ADD',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: screenWidth > 800 ? 12 : 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Products Grid
                      Expanded(
                        child: Container(
                          color: Colors.grey.shade50,
                          padding: EdgeInsets.all(screenWidth > 800 ? 20 : 12),
                          child: Consumer<ProductsProvider>(
                            builder: (context, productsProv, _) {
                              if (productsProv.loading &&
                                  productsProv.products.isEmpty) {
                                return const Center(
                                  child: CircularProgressIndicator(
                                    color: Color(0xFF0277FA),
                                  ),
                                );
                              }

                              if (productsProv.error != null &&
                                  productsProv.products.isEmpty) {
                                return Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        productsProv.error!,
                                        style: const TextStyle(
                                          color: Colors.red,
                                        ),
                                      ),
                                      const SizedBox(height: 20),
                                      ElevatedButton(
                                        onPressed: () => productsProv.refresh(),
                                        child: const Text('Retry'),
                                      ),
                                    ],
                                  ),
                                );
                              }

                              return Column(
                                children: [
                                  // Product count and pagination controls
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 12,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        // Text(
                                        //   '${productsProv.filteredProductsCount} products found',
                                        //   style: TextStyle(
                                        //     color: Colors.grey.shade600,
                                        //     fontSize: screenWidth > 800
                                        //         ? 14
                                        //         : 12,
                                        //   ),
                                        // ),

                                        // Refresh button
                                        IconButton(
                                          onPressed: () =>
                                              productsProv.refresh(),
                                          icon: const Icon(Icons.refresh),
                                          tooltip: 'Refresh',
                                        ),

                                        // Client-side pagination (for filtered results) please dont tell me to make the filtiring on the backend while ik u will do
                                        //  if (productsProv.totalPages > 1)
                                        Row(
                                          children: [
                                            IconButton(
                                              icon: Icon(
                                                Icons.arrow_back_ios,
                                                size: screenWidth > 800
                                                    ? 16
                                                    : 14,
                                                color: const Color(0xFF0277FA),
                                                // productsProv.currentPage > 1
                                                // ? const Color(0xFF0277FA)
                                                // : Colors.grey.shade400,
                                              ),
                                              onPressed:
                                                  productsProv.currentPage > 1
                                                  ? () => productsProv
                                                        .previousPage()
                                                  : null,
                                              tooltip: 'Previous Page',
                                            ),
                                            Text(
                                              'Page ${productsProv.currentPage}', //of ${productsProv.totalPages}
                                              style: TextStyle(
                                                color: Colors.grey.shade600,
                                                fontSize: screenWidth > 800
                                                    ? 14
                                                    : 12,
                                              ),
                                            ),
                                            IconButton(
                                              icon: Icon(
                                                Icons.arrow_forward_ios,
                                                size: screenWidth > 800
                                                    ? 16
                                                    : 14,
                                                color: const Color(0xFF0277FA),
                                                // productsProv.currentPage <
                                                //     productsProv.totalPages
                                                // ? const Color(0xFF0277FA)
                                                // : Colors.grey.shade400,
                                              ),
                                              onPressed: () {
                                                if (productsProv.loadingMore) {
                                                  productsProv
                                                      .loadMoreProducts();
                                                  debugPrint(
                                                    "am i even getting executed line 960 pos_dashboard",
                                                  );
                                                } else {
                                                  null;
                                                } // this code is probably useless rn but imma keep it so i dont break something that was working before
                                                // if (productsProv.currentPage <
                                                //     productsProv.totalPages) {
                                                productsProv.nextPage();
                                                productsProv.loadMoreProducts();
                                                // } else {
                                                //   null;
                                                // }
                                              },
                                              tooltip: 'Next Page',
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),

                                  // Products Grid
                                  Expanded(
                                    child: GridView.builder(
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                            crossAxisCount: gridCrossAxisCount,
                                            crossAxisSpacing: screenWidth > 800
                                                ? 16
                                                : 12,
                                            mainAxisSpacing: screenWidth > 800
                                                ? 16
                                                : 12,
                                            childAspectRatio:
                                                gridChildAspectRatio,
                                          ),
                                      itemCount:
                                          productsProv.products.length + (0),
                                      // itemCount:
                                      // productsProv.products.length +
                                      // (productsProv.hasMore ? 1 : 0),
                                      itemBuilder: (_, i) {
                                        // Load more indicator card
                                        // if (i == productsProv.products.length &&
                                        //     productsProv.hasMore) {
                                        //   return Container(
                                        //     decoration: BoxDecoration(
                                        //       color: Colors.white,
                                        //       borderRadius:
                                        //           BorderRadius.circular(12),
                                        //       boxShadow: [
                                        //         BoxShadow(
                                        //           color: Colors.black
                                        //               .withOpacity(0.05),
                                        //           blurRadius: 8,
                                        //           offset: const Offset(0, 3),
                                        //         ),
                                        //       ],
                                        //     ),
                                        //     child: Column(
                                        //       mainAxisAlignment:
                                        //           MainAxisAlignment.center,
                                        //       children: [
                                        //         if (productsProv.loadingMore)
                                        //           const CircularProgressIndicator(
                                        //             color: Color(0xFF0277FA),
                                        //           )
                                        //         else
                                        //           Column(
                                        //             children: [
                                        //               Icon(
                                        //                 Icons
                                        //                     .add_circle_outline,
                                        //                 color: const Color(
                                        //                   0xFF0277FA,
                                        //                 ),
                                        //                 size: 40,
                                        //               ),
                                        //               const SizedBox(
                                        //                 height: 12,
                                        //               ),
                                        //               Text(
                                        //                 'Load More',
                                        //                 style: TextStyle(
                                        //                   color: const Color(
                                        //                     0xFF0277FA,
                                        //                   ),
                                        //                   fontWeight:
                                        //                       FontWeight.bold,
                                        //                   fontSize:
                                        //                       screenWidth > 800
                                        //                       ? 14
                                        //                       : 12,
                                        //                 ),
                                        //               ),
                                        //               const SizedBox(height: 8),
                                        //               Text(
                                        //                 '${productsProv.totalProductsCount} total products',
                                        //                 style: TextStyle(
                                        //                   color: Colors
                                        //                       .grey
                                        //                       .shade600,
                                        //                   fontSize:
                                        //                       screenWidth > 800
                                        //                       ? 12
                                        //                       : 10,
                                        //                 ),
                                        //               ),
                                        //             ],
                                        //           ),
                                        //         ElevatedButton(
                                        //           onPressed:
                                        //               productsProv.loadingMore
                                        //               ? null
                                        //               : () => productsProv
                                        //                     .loadMoreProducts(),
                                        //           style:
                                        //               ElevatedButton.styleFrom(
                                        //                 backgroundColor:
                                        //                     const Color(
                                        //                       0xFF0277FA,
                                        //                     ),
                                        //                 minimumSize: const Size(
                                        //                   120,
                                        //                   40,
                                        //                 ),
                                        //               ),
                                        //           child:
                                        //               productsProv.loadingMore
                                        //               ? const SizedBox(
                                        //                   width: 16,
                                        //                   height: 16,
                                        //                   child:
                                        //                       CircularProgressIndicator(
                                        //                         strokeWidth: 2,
                                        //                         color: Colors
                                        //                             .white,
                                        //                       ),
                                        //                 )
                                        //               : const Text('LOAD MORE'),
                                        //         ),
                                        //       ],
                                        //     ),
                                        //   );
                                        // }

                                        // Product card
                                        final p = productsProv.products[i];

                                        return SubtleHoverDelete(
                                          child: GestureDetector(
                                            onTap: () => context
                                                .read<CartProvider>()
                                                .addToCart(p),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black
                                                        .withOpacity(0.05),
                                                    blurRadius: 8,
                                                    offset: const Offset(0, 3),
                                                  ),
                                                ],
                                              ),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  // Product Image
                                                  Expanded(
                                                    child: Container(
                                                      width: double.infinity,
                                                      decoration: BoxDecoration(
                                                        color: Colors
                                                            .grey
                                                            .shade100,
                                                        borderRadius:
                                                            const BorderRadius.only(
                                                              topLeft:
                                                                  Radius.circular(
                                                                    12,
                                                                  ),
                                                              topRight:
                                                                  Radius.circular(
                                                                    12,
                                                                  ),
                                                            ),
                                                      ),
                                                      child:
                                                          p.imageUrl != null &&
                                                              p
                                                                  .imageUrl!
                                                                  .isNotEmpty
                                                          ? ClipRRect(
                                                              borderRadius:
                                                                  const BorderRadius.only(
                                                                    topLeft:
                                                                        Radius.circular(
                                                                          12,
                                                                        ),
                                                                    topRight:
                                                                        Radius.circular(
                                                                          12,
                                                                        ),
                                                                  ),
                                                              child: Image.network(
                                                                p.imageUrl!,
                                                                fit: BoxFit
                                                                    .cover,
                                                                errorBuilder:
                                                                    (
                                                                      context,
                                                                      error,
                                                                      stackTrace,
                                                                    ) {
                                                                      return Center(
                                                                        child: Icon(
                                                                          Icons
                                                                              .image_not_supported,
                                                                          color: Colors
                                                                              .grey
                                                                              .shade400,
                                                                          size:
                                                                              32,
                                                                        ),
                                                                      );
                                                                    },
                                                              ),
                                                            )
                                                          : Center(
                                                              child: Icon(
                                                                Icons.image,
                                                                color: Colors
                                                                    .grey
                                                                    .shade400,
                                                                size: 40,
                                                              ),
                                                            ),
                                                    ),
                                                  ),

                                                  // Product Info
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                          12,
                                                        ),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          p.name,
                                                          style: TextStyle(
                                                            fontSize:
                                                                screenWidth >
                                                                    800
                                                                ? 14
                                                                : 13,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color:
                                                                Colors.black87,
                                                          ),
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                        ),
                                                        const SizedBox(
                                                          height: 8,
                                                        ),
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Text(
                                                              '\$${p.price.toStringAsFixed(2)}',
                                                              style: TextStyle(
                                                                fontSize:
                                                                    screenWidth >
                                                                        800
                                                                    ? 16
                                                                    : 14,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color:
                                                                    const Color(
                                                                      0xFF0277FA,
                                                                    ),
                                                              ),
                                                            ),
                                                            Container(
                                                              padding:
                                                                  const EdgeInsets.symmetric(
                                                                    horizontal:
                                                                        8,
                                                                    vertical: 4,
                                                                  ),
                                                              decoration: BoxDecoration(
                                                                color:
                                                                    p.stock <= 5
                                                                    ? Colors
                                                                          .red
                                                                          .shade50
                                                                    : p.stock <=
                                                                          20
                                                                    ? Colors
                                                                          .orange
                                                                          .shade50
                                                                    : Colors
                                                                          .green
                                                                          .shade50,
                                                                borderRadius:
                                                                    BorderRadius.circular(
                                                                      4,
                                                                    ),
                                                                border: Border.all(
                                                                  color:
                                                                      p.stock <=
                                                                          5
                                                                      ? Colors
                                                                            .red
                                                                            .shade200
                                                                      : p.stock <=
                                                                            20
                                                                      ? Colors
                                                                            .orange
                                                                            .shade200
                                                                      : Colors
                                                                            .green
                                                                            .shade200,
                                                                  width: 1,
                                                                ),
                                                              ),
                                                              child: Text(
                                                                '${p.stock} left',
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      screenWidth >
                                                                          800
                                                                      ? 11
                                                                      : 10,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color:
                                                                      p.stock <=
                                                                          5
                                                                      ? Colors
                                                                            .red
                                                                            .shade700
                                                                      : p.stock <=
                                                                            20
                                                                      ? Colors
                                                                            .orange
                                                                            .shade700
                                                                      : Colors
                                                                            .green
                                                                            .shade700,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          onArchive: () =>
                                              _archiveProduct(p.id),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // ================= RIGHT ORDER PANEL =================
                Container(
                  width: cartPanelWidth.toDouble(),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      left: BorderSide(color: Colors.grey.shade300),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(-5, 0),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Order Header
                      Container(
                        height: 80,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(color: Colors.grey.shade300),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.shopping_bag,
                              color: Colors.grey.shade700,
                              size: 24,
                            ),
                            const SizedBox(width: 12),
                            const Text(
                              'Order Details',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                            const Spacer(),
                            if (context.watch<CartProvider>().cart.isNotEmpty)
                              IconButton(
                                icon: Icon(
                                  Icons.clear_all,
                                  color: const Color(0xFF0277FA),
                                  size: 22,
                                ),
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                      title: const Text('Clear Cart'),
                                      content: const Text(
                                        'Are you sure you want to clear all items from the cart?',
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context),
                                          child: const Text('Cancel'),
                                        ),
                                        TextButton(
                                          onPressed: () {
                                            context
                                                .read<CartProvider>()
                                                .clearCart();
                                            Navigator.pop(context);
                                          },
                                          child: const Text('Clear'),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                                tooltip: 'Clear Cart',
                              ),
                          ],
                        ),
                      ),

                      // Order Items
                      Expanded(
                        child: context.watch<CartProvider>().cart.isEmpty
                            ? Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(20),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.shopping_cart_outlined,
                                        color: Colors.grey.shade300,
                                        size: screenHeight * 0.15,
                                      ),
                                      const SizedBox(height: 20),
                                      Text(
                                        'No items in cart',
                                        style: TextStyle(
                                          fontSize: screenWidth > 800 ? 16 : 14,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        'Add products to cart',
                                        style: TextStyle(
                                          fontSize: screenWidth > 800 ? 14 : 12,
                                          color: Colors.grey.shade500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : ListView.builder(
                                padding: const EdgeInsets.all(20),
                                itemCount: context
                                    .watch<CartProvider>()
                                    .cart
                                    .length,
                                itemBuilder: (_, i) {
                                  final item = context
                                      .watch<CartProvider>()
                                      .cart
                                      .values
                                      .elementAt(i);
                                  return Container(
                                    margin: const EdgeInsets.only(bottom: 12),
                                    padding: const EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: Colors.grey.shade200,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.02),
                                          blurRadius: 4,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: Text(
                                                item.product.name,
                                                style: const TextStyle(
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.black87,
                                                ),
                                              ),
                                            ),
                                            Text(
                                              '\$${(item.product.price * item.quantity).toStringAsFixed(2)}',
                                              style: const TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold,
                                                color: Color(0xFF0277FA),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 12),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              '${item.quantity}x @ \$${item.product.price.toStringAsFixed(2)} each',
                                              style: TextStyle(
                                                fontSize: 13,
                                                color: Colors.grey.shade600,
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                color: Colors.grey.shade50,
                                                borderRadius:
                                                    BorderRadius.circular(6),
                                                border: Border.all(
                                                  color: Colors.grey.shade200,
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  IconButton(
                                                    icon: Icon(
                                                      Icons.remove,
                                                      size: 18,
                                                      color:
                                                          Colors.grey.shade700,
                                                    ),
                                                    onPressed: () =>
                                                        _removeFromCart(
                                                          item.product.id,
                                                        ),
                                                    padding: EdgeInsets.zero,
                                                    constraints:
                                                        const BoxConstraints(
                                                          minWidth: 36,
                                                          minHeight: 36,
                                                        ),
                                                  ),
                                                  Container(
                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                          horizontal: 12,
                                                        ),
                                                    child: Text(
                                                      '${item.quantity}',
                                                      style: const TextStyle(
                                                        fontSize: 14,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color: Colors.black,
                                                      ),
                                                    ),
                                                  ),
                                                  IconButton(
                                                    icon: Icon(
                                                      Icons.add,
                                                      size: 18,
                                                      color:
                                                          Colors.grey.shade700,
                                                    ),
                                                    onPressed: () => context
                                                        .read<CartProvider>()
                                                        .addToCart(
                                                          item.product,
                                                        ),
                                                    padding: EdgeInsets.zero,
                                                    constraints:
                                                        const BoxConstraints(
                                                          minWidth: 36,
                                                          minHeight: 36,
                                                        ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                      ),

                      // Order Summary
                      if (context.watch<CartProvider>().cart.isNotEmpty)
                        Container(
                          padding: EdgeInsets.all(screenWidth > 800 ? 24 : 16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border(
                              top: BorderSide(
                                color: Colors.grey.shade300,
                                width: 1.5,
                              ),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 10,
                                offset: const Offset(0, -5),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'Total',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                  ),
                                  Text(
                                    '\$${(context.watch<CartProvider>().cart.values.fold<double>(0, (s, i) => s + i.total)).toStringAsFixed(2)}',
                                    style: const TextStyle(
                                      fontSize: 26,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF0277FA),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 24),
                              ElevatedButton(
                                onPressed: _handleCheckout,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF0277FA),
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 18,
                                  ),
                                  minimumSize: const Size(double.infinity, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  elevation: 2,
                                ),
                                child: const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Pay Now',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    Icon(
                                      Icons.arrow_forward,
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
// ive reched 1779 lines of code i need to fix that 
//now ive reached 2006 lines one line and its my birthday
//here we go 10/2/2007 