class productModel {
  final int id;
  final String name;
  final double price;
  final int stock;
  final String? imageUrl;
  // final int? nextCursor;
  // final int? remaining_count;

  productModel({
    required this.id,
    required this.name,
    required this.price,
    required this.stock,
    this.imageUrl,
    // this.nextCursor,
    // this.remaining_count,
  });

  factory productModel.fromJson(Map<String, dynamic> json) {
    return productModel(
      id: json['id'],
      name: json['name'],
      price: double.parse(json['price'].toString()),
      stock: json['storage_quantity'],
      imageUrl: json['image_url'] != null ? json['image_url'].toString() : null,
      // nextCursor: json['next_cursor'],
      // remaining_count: json['remaining_count'],
    );
  }
}

// for testing the pagination
// class ProductResponse {
//   final List<dynamic> products;
//   final int count;
//   final int? nextCursor;

//   ProductResponse({
//     required this.products,
//     required this.count,
//     this.nextCursor,
//   });

//   factory ProductResponse.fromJson(Map<String, dynamic> json) {
//     return ProductResponse(
//       products: json['products'],
//       count: json['count'],
//       nextCursor: json['next_cursor'],
//     );
//   }
// }

class ResponseModel {
  final int? nextCursor;
  final int? remaining_count;

  ResponseModel({this.nextCursor, this.remaining_count});

  factory ResponseModel.fromJson(Map<String, dynamic> json) {
    return ResponseModel(
      nextCursor: json['next_cursor'],
      remaining_count: json['remaining_count'],
    );
  }
}

// class Product {
//   final int id;
//   final String name;
//   final double price;
//   final int stock;
//   final String? imageUrl;

//   product({
//     required this.id,
//     required this.name,
//     required this.price,
//     required this.stock,
//     this.imageUrl,
//   });
// }

// class Response {
//   final List<dynamic> products;
//   final int count;
//   final int? nextCursor;

//   Response({
//     required this.products,
//     required this.count,
//     this.nextCursor,
//   });
// }
