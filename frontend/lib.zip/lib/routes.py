from flask import Blueprint, request, jsonify
from database import db
import mysql.connector

api = Blueprint('api', __name__)

@api.route('/')
def home():
    """Home endpoint - API status"""
    return jsonify({
        'message': 'POS System API',
        'status': 'running',
        'endpoints': {
            'products': '/products',
            'orders': '/orders',
            'health': '/health'
            #remember to add the new api routes
        }
    })


@api.route('/health', methods=['GET'])
def health_check():
    """Check if API and database are healthy"""
    if db.test_connection():
        return jsonify({'status': 'healthy', 'database': 'connected'})
    return jsonify({'status': 'unhealthy', 'database': 'disconnected'}), 500


@api.route('/products', methods=['GET'])
def get_all_products():
    """Get all products from database"""
    connection = db.get_connection()
    if not connection:
        return jsonify({'error': 'Database connection failed'}), 500

    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM product WHERE is_archived = 0")#is archived = 0 the product is theere = 1 the product is archived
        products = cursor.fetchall()
        return jsonify({'products': products, 'count': len(products)})
    except mysql.connector.Error as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close_connection(connection, cursor)


@api.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Get a single product by ID"""
    connection = db.get_connection()
    if not connection:
        return jsonify({'error': 'Database connection failed'}), 500

    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM product WHERE id = %s", (product_id,))
        product = cursor.fetchone()
        if product:
            return jsonify(product)
        return jsonify({'error': 'Product not found'}), 404
    except mysql.connector.Error as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close_connection(connection, cursor)


@api.route('/products', methods=['POST'])
def create_product():
    """Create a new product"""
    data = request.get_json()

    # Validate required fields
    if not data or 'name' not in data or 'price' not in data:
        return jsonify({'error': 'Name and price are required'}), 400

    connection = db.get_connection()
    if not connection:
        return jsonify({'error': 'Database connection failed'}), 500

    cursor = connection.cursor()
    try:
        query = """
        INSERT INTO product (name, price, storage_quantity) 
        VALUES (%s, %s, %s)
        """
        values = (
            data['name'],
            data['price'],
            data.get('storage_quantity', 0)
        )

        cursor.execute(query, values)
        connection.commit()
        product_id = cursor.lastrowid

        return jsonify({
            'message': 'Product created successfully',
            'product_id': product_id
        }), 201
    except mysql.connector.Error as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close_connection(connection, cursor)

# home made :)
#imma make it archive insted of delete
@api.route('/products/archive/<int:product_id>', methods=['PUT'])
def archive_product(product_id):
    """ARCHIVE a product by ID"""
    connection = db.get_connection()
    if not connection:
        return jsonify({'error': 'Database connection failed'}), 500
    
    cursor = connection.cursor()
    try:
        #cursor.execute("DELETE FROM product WHERE id = %s", (product_id,))
        #forget all this crap imma implement soft delete method where is deleted = 1 means deleted and is deleted = 0 means not deleted

        cursor.execute("UPDATE product SET is_archived = 1 WHERE id = %s", (product_id,))
        connection.commit()
       

        if cursor.rowcount == 0:
            return jsonify({'error': 'Product not found'}), 404

        return jsonify({'message': 'Product archived successfully'}), 200
    except mysql.connector.Error as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close_connection(connection, cursor)



# @api.route('/orders', methods=['POST'])
# def create_order():
#     """Create a new order with items"""
#     data = request.get_json()

#     if not data or 'items' not in data or not data['items']:
#         return jsonify({'error': 'Order must contain items'}), 400

#     connection = db.get_connection()
#     if not connection:
#         return jsonify({'error': 'Database connection failed'}), 500

#     cursor = connection.cursor(dictionary=True)

#     try:
#         # Start transaction
#         connection.start_transaction()

#         # Step 1: Calculate total price and check stock
#         total_price = 0
#         order_items = []

#         for item in data['items']:
#             product_id = item.get('product_id')
#             quantity = item.get('quantity', 1)

#             # Get product details
#             cursor.execute(
#                 "SELECT id, name, price, storage_quantity FROM product WHERE id = %s",
#                 (product_id,)
#             )
#             product = cursor.fetchone()

#             if not product:
#                 return jsonify({'error': f'Product {product_id} not found'}), 404

#             if product['storage_quantity'] < quantity:
#                 return jsonify({
#                     'error': f'Insufficient stock for {product["name"]}. '
#                              f'Available: {product["storage_quantity"]}, Requested: {quantity}'
#                 }), 400

#             # Calculate item total
#             item_total = product['price'] * quantity
#             total_price += item_total

#             order_items.append({
#                 'product_id': product_id,
#                 'quantity': quantity,
#                 'unit_price': product['price'],
#                 'product': product
#             })

#         # Step 2: Create order record
#         cursor.execute(
#             "INSERT INTO orders (total_price, status) VALUES (%s, %s)",
#             (total_price, 'pending')
#         )
#         order_id = cursor.lastrowid

#         # Step 3: Create order items and update stock
#         for item in order_items:
#             # Insert ordered item
#             cursor.execute(
#                 """INSERT INTO ordered_item 
#                    (product_id, order_id, ordered_quantity, unit_price) 
#                    VALUES (%s, %s, %s, %s)""",
#                 (item['product_id'], order_id, item['quantity'], item['unit_price'])
#             )

#             # Update product stock
#             cursor.execute(
#                 "UPDATE product SET storage_quantity = storage_quantity - %s WHERE id = %s",
#                 (item['quantity'], item['product_id'])
#             )

#         # Step 4: Update order status to completed
#         cursor.execute(
#             "UPDATE orders SET status = 'completed' WHERE id = %s",
#             (order_id,)
#         )

#         # Commit transaction
#         connection.commit()

#         return jsonify({
#             'message': 'Order created successfully',
#             'order_id': order_id,
#             'total_price': total_price,
#             'items_count': len(order_items)
#         }), 201

#     except mysql.connector.Error as e:
#         # Rollback in case of error
#         connection.rollback()
#         return jsonify({'error': str(e)}), 500
#     finally:
#         db.close_connection(connection, cursor)

# a new order api route new 


#fetch orders api route
# @api.route('/fetchorders', methods=['GET'])
# def get_order():
#     """fetxh all the orders"""
#     connection = db.get_connection()
#     if not connection:
#         return jsonify({'error': 'Database connection failed'}), 500

#     cursor = connection.cursor(dictionary=True)
#     try:
#         # Get order info
#         cursor.execute("SELECT * FROM orders")
#         order = cursor.fetchone()

#         if not order:
#             return jsonify({'error': 'Order not found'}), 404

        # Get order items
        # cursor.execute("""
        #     SELECT oi.*, p.name as product_name 
        #     FROM ordered_item oi
        #     JOIN product p ON oi.product_id = p.id
        #     WHERE oi.order_id = %s
        # """, (order_id,))
    #     items = cursor.fetchall()

    #     order['items'] = items
    #     return jsonify(order)

    # except mysql.connector.Error as e:
    #     return jsonify({'error': str(e)}), 500
    # finally:
    #     db.close_connection(connection, cursor)




@api.route('/orders', methods=['POST'])#MARK: NEW ORDER API ROUTE
def create_order():
    """Process a checkout: Snapshot prices, create order, and update stock"""
    data = request.get_json()

    # Expected JSON: {"items": [{"product_id": 1, "quantity": 2}, {"product_id": 2, "quantity": 1}]}
    if not data or 'items' not in data or not data['items']:
        return jsonify({'error': 'Order must contain items'}), 400 

    connection = db.get_connection()
    if not connection: 
        return jsonify({'error': 'Database connection failed'}), 500
    
    cursor = connection.cursor(dictionary=True)

    try: 
        # Start transaction: if one item fails, the whole order is canceled
        connection.start_transaction()

        # Step 1: Create the 'Parent' Order entry
        cursor.execute("INSERT INTO orders (total_price) VALUES (%s)", (0,))
        order_id = cursor.lastrowid        
        
        total_order_price = 0 

        # Step 2: Loop through items and create "Snapshots"
        for item in data['items']:
            pid = item.get('product_id')
            qty = item.get('quantity', 1)

            # Get the current "Live" price from inventory
            cursor.execute("SELECT name, price, storage_quantity FROM product WHERE id = %s", (pid,))
            product = cursor.fetchone()

            if not product:
                connection.rollback()
                return jsonify({'error': f'Product {pid} not found'}), 404
            
            if product['storage_quantity'] < qty:
                connection.rollback()
                return jsonify({'error': f'Insufficient stock for {product["name"]}'}), 400
            
            # SNAPSHOT CALCULATION
            current_unit_price = product['price'] 
            item_total = current_unit_price * qty
            total_order_price += item_total # Accumulates total for all items

            # Step 3: Insert into ordered_item using your EXACT column: 'quantity'
            cursor.execute("""
                INSERT INTO ordered_item (order_id, product_id, quantity, unit_price) 
                VALUES (%s, %s, %s, %s)
            """, (order_id, pid, qty, current_unit_price))

            # Step 4: Deduct from inventory (IT WORKD RN) i have top edit the ui now so it updates the ui whenever i click the checkout button and removes one the quantity from the item in the ui
            # cursor.execute(
            #      "UPDATE product SET storage_quantity = storage_quantity - %s WHERE id = %s", 
            #      (qty, pid)
            #  )
            cursor.execute(
                "UPDATE product SET storage_quantity = storage_quantity - %s WHERE id = %s", 
                (qty, pid)
            )

        # Step 5: Update the final total in the parent order table
        cursor.execute("UPDATE orders SET total_price = %s WHERE id = %s", (total_order_price, order_id))

        # Finalize the transaction
        connection.commit()
        
        return jsonify({
            'message': 'Checkout complete',
            'order_id': order_id,
            'total': float(total_order_price)
        }), 201
    
    except mysql.connector.Error as e:
        connection.rollback() # Safely undo everything on error
        return jsonify({'error': str(e)}), 500
    finally: 
        db.close_connection(connection, cursor)

        """CREATE TABLE ordered_item (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0), -- Corrected column name here!
    unit_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES `orders`(id) ON DELETE CASCADE, -- Escaped if 'orders' is a keyword
    FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE RESTRICT
);


UPDATE table_name
SET quantity = quantity - 1
WHERE product_id = the id i get from the user;

        """


@api.route('/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    """Get order details with items"""
    connection = db.get_connection()
    if not connection:
        return jsonify({'error': 'Database connection failed'}), 500

    cursor = connection.cursor(dictionary=True)
    try:
        # Get order info
        cursor.execute("SELECT * FROM orders WHERE id = %s", (order_id,))
        order = cursor.fetchone()

        if not order:
            return jsonify({'error': 'Order not found'}), 404

        # Get order items
        cursor.execute("""
            SELECT oi.*, p.name as product_name 
            FROM ordered_item oi
            JOIN product p ON oi.product_id = p.id
            WHERE oi.order_id = %s
        """, (order_id,))
        items = cursor.fetchall()

        order['items'] = items
        return jsonify(order)

    except mysql.connector.Error as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close_connection(connection, cursor)


@api.route('/orders', methods=['GET'])
def get_all_orders():
    """Return all orders with their items"""
    connection = db.get_connection()
    if not connection:
        return jsonify({'error': 'Database connection failed'}), 500

    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM orders ORDER BY id DESC")
        orders = cursor.fetchall()

        # attach items for each order
        for order in orders:
            cursor.execute(
                """
                SELECT oi.*, p.name as product_name
                FROM ordered_item oi
                JOIN product p ON oi.product_id = p.id
                WHERE oi.order_id = %s
                """,
                (order['id'],)
            )
            items = cursor.fetchall()
            order['items'] = items

        return jsonify({'orders': orders, 'count': len(orders)})
    except mysql.connector.Error as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close_connection(connection, cursor)


@api.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    """Update product information"""
    data = request.get_json()

    if not data:
        return jsonify({'error': 'No data provided'}), 400

    connection = db.get_connection()
    if not connection:
        return jsonify({'error': 'Database connection failed'}), 500

    cursor = connection.cursor()
    try:
        # Build update query dynamically based on provided fields
        update_fields = []
        values = []

        if 'name' in data:
            update_fields.append("name = %s")
            values.append(data['name'])

        if 'price' in data:
            update_fields.append("price = %s")
            values.append(data['price'])

        if 'storage_quantity' in data:
            update_fields.append("storage_quantity = %s")
            values.append(data['storage_quantity'])

        if not update_fields:
            return jsonify({'error': 'No fields to update'}), 400

        values.append(product_id)
        query = f"UPDATE product SET {', '.join(update_fields)} WHERE id = %s"

        cursor.execute(query, values)
        connection.commit()

        if cursor.rowcount == 0:
            return jsonify({'error': 'Product not found'}), 404

        return jsonify({'message': 'Product updated successfully'})

    except mysql.connector.Error as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close_connection(connection, cursor)